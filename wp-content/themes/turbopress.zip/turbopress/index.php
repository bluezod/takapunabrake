<?php 
	global $SMTheme;
	
	get_header(); 
	get_template_part('theloop');
	get_template_part('navigation');
	
	
	get_footer();
	
	
?>