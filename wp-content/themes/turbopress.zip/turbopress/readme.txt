Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/turbopress/
Buy theme: http://smthemes.com/buy/turbopress/
Support Forums: http://smthemes.com/support/forum/turbopress-free-wordpress-theme